
// script.js
document.getElementById("mobileToggle").addEventListener("click", () => {
  document.getElementById("navMenu").classList.toggle("active");
});
